import random
tank_level=75
temperature=32
pump_status='OFF'
print('Industrial SCADA Interface')
print('Tank Level:',tank_level,'%')
print('Temperature:',temperature,'C')
print('Pump:',pump_status)
pump_status='ON'
print('Pump Started')
